package org.cap.pojo;

import javax.validation.constraints.Min;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;

public class Book {

	@Min(value = 100, message = "* Please enter Book Id greather than 100.")
	private int bookId;

	@NotEmpty(message = "* Please Enter BookName.")
	private String bookName;

	@Range(min = 100, max = 5000, message = "* Price should be between 100 and 5000.")
	private double price;

	@NotEmpty(message = "* Please enter author")
	@Length(min = 5, max = 25, message = "* Characters should be between 5 and 25.")
	private String author;

	@Email(message = "* Please enter Valid Email Id.")
	@NotEmpty(message = "* Please enter Email.")
	private String authorEmail;

	public Book() {

	}

	public Book(int bookId, String bookName, double price, String author) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.price = price;
		this.author = author;

	}

	public Book(int bookId, String bookName, double price, String author,
			String authorEmail) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.price = price;
		this.author = author;

		this.authorEmail = authorEmail;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getAuthorEmail() {
		return authorEmail;
	}

	public void setAuthorEmail(String authorEmail) {
		this.authorEmail = authorEmail;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", price="
				+ price + ", author=" + author + ",  authorEmail="
				+ authorEmail + "]";
	}

}
